import asyncio
import inspect
import json
import logging
import ssl
import threading
import time
from functools import cached_property
from typing import (
    Any,
    AsyncIterator,
    Dict,
    Iterator,
    List,
    Literal,
    Optional,
    Tuple,
    Type,
    TypeVar,
    Union,
)

import httpx
import pydantic
from typing_extensions import Self

from gigachat._types import FileContent, FileTypes
from gigachat.api import auth, chat, chat_completions
from gigachat.authentication import _awith_auth, _awith_auth_stream, _with_auth, _with_auth_stream
from gigachat.context import authorization_cvar
from gigachat.exceptions import LengthFinishReasonError
from gigachat.models.auth import AccessToken, Token
from gigachat.models.batches import Batch, Batches
from gigachat.models.chat import (
    Chat,
    ChatCompletion,
    ChatCompletionChunk,
    Function,
    Messages,
    MessagesRole,
)
from gigachat.models.chat_completions import (
    ChatCompletionChunk as PrimaryChatCompletionChunk,
)
from gigachat.models.chat_completions import (
    ChatCompletionRequest,
    ChatCompletionResponse,
    ChatMessage,
    ChatResponseFormat,
    ChatStorage,
)
from gigachat.models.embeddings import Embeddings
from gigachat.models.files import DeletedFile, File, UploadedFile, UploadedFiles
from gigachat.models.models import Model, Models
from gigachat.models.response_format import JsonSchemaResponseFormat
from gigachat.models.tools import AICheckResult, Balance, FunctionValidationResult, OpenApiFunctions, TokensCount
from gigachat.resources import (
    AICheckAsyncResource,
    AICheckSyncResource,
    AssistantsAsyncClient,
    AssistantsSyncClient,
    AsyncChatNamespace,
    BalanceAsyncResource,
    BalanceSyncResource,
    BatchesAsyncResource,
    BatchesSyncResource,
    ChatNamespace,
    EmbeddingsAsyncResource,
    EmbeddingsSyncResource,
    FilesAsyncResource,
    FilesSyncResource,
    FunctionsAsyncResource,
    FunctionsSyncResource,
    ModelsAsyncResource,
    ModelsSyncResource,
    ThreadsAsyncClient,
    ThreadsSyncClient,
    TokensAsyncResource,
    TokensSyncResource,
    warn_deprecated_resource_api,
)
from gigachat.retry import _awith_retry, _awith_retry_stream, _with_retry, _with_retry_stream
from gigachat.settings import Settings

ModelT = TypeVar("ModelT", bound=pydantic.BaseModel)

logger = logging.getLogger(__name__)

GIGACHAT_MODEL = "GigaChat"


def _get_kwargs(settings: Settings) -> Dict[str, Any]:
    """Return settings for connecting to the GigaChat API."""
    kwargs = {
        "base_url": settings.base_url,
        "verify": settings.verify_ssl_certs,
        "timeout": httpx.Timeout(settings.timeout),
    }
    if settings.ssl_context:
        kwargs["verify"] = settings.ssl_context
    if settings.ca_bundle_file:
        kwargs["verify"] = settings.ca_bundle_file
    if settings.cert_file:
        kwargs["cert"] = (
            settings.cert_file,
            settings.key_file,
            settings.key_file_password,
        )
    if settings.max_connections is not None:
        kwargs["limits"] = httpx.Limits(max_connections=settings.max_connections)
    return kwargs


def _get_auth_kwargs(settings: Settings) -> Dict[str, Any]:
    """Return settings for connecting to the OAuth 2.0 authorization server."""
    kwargs = {
        "verify": settings.verify_ssl_certs,
        "timeout": httpx.Timeout(settings.timeout),
    }
    if settings.ssl_context:
        kwargs["verify"] = settings.ssl_context
    if settings.ca_bundle_file:
        kwargs["verify"] = settings.ca_bundle_file
    return kwargs


def _validate_response_format(payload: Union[Chat, Dict[str, Any], str]) -> None:
    """Raise TypeError if response_format is a Pydantic model on the root chat path."""
    if isinstance(payload, dict):
        response_format = payload.get("response_format")
    elif isinstance(payload, Chat):
        response_format = payload.response_format
    else:
        return
    if (
        response_format is not None
        and inspect.isclass(response_format)
        and issubclass(response_format, pydantic.BaseModel)
    ):
        raise TypeError(
            "You tried to pass a Pydantic model to `chat(response_format=...)`; "
            "use `client.chat_parse(payload, response_format=...)` or "
            "`client.achat_parse(payload, response_format=...)` instead"
        )


def _parse_chat(payload: Union[Chat, Dict[str, Any], str], settings: Settings) -> Chat:
    if isinstance(payload, str):
        chat = Chat(messages=[Messages(role=MessagesRole.USER, content=payload)])
    else:
        chat = Chat.model_validate(payload)
    using_assistant = chat.storage is not None and (chat.storage.assistant_id or chat.storage.thread_id)
    if not using_assistant and chat.model is None:
        chat.model = settings.model or GIGACHAT_MODEL
    if chat.profanity_check is None:
        chat.profanity_check = settings.profanity_check
    if chat.flags is None:
        chat.flags = settings.flags
    return chat


def _prepare_chat_for_parse(
    payload: Union[Chat, Dict[str, Any], str],
    settings: Settings,
    response_format: Type[pydantic.BaseModel],
    strict: bool,
) -> Chat:
    """Prepare a Chat object with response_format derived from *response_format*."""
    chat_data = _parse_chat(payload, settings)
    chat_data.response_format = JsonSchemaResponseFormat(schema=response_format, strict=strict)
    return chat_data


def _prepare_chat_completion_for_parse(
    payload: Union[ChatCompletionRequest, Dict[str, Any], str],
    settings: Settings,
    response_format: Type[pydantic.BaseModel],
    strict: bool,
) -> ChatCompletionRequest:
    """Prepare a primary chat completion request with a structured response schema."""
    chat_data = _parse_chat_completion(payload, settings)
    chat_data.response_format = ChatResponseFormat(type="json_schema", schema=response_format, strict=strict)
    return chat_data


def _parse_chat_completion(
    payload: Union[ChatCompletionRequest, Dict[str, Any], str],
    settings: Settings,
) -> ChatCompletionRequest:
    if isinstance(payload, str):
        chat = ChatCompletionRequest(messages=[ChatMessage(role="user", content=payload)])
    else:
        chat = ChatCompletionRequest.model_validate(payload)

    using_assistant = chat.assistant_id is not None or (
        isinstance(chat.storage, ChatStorage) and chat.storage.thread_id is not None
    )
    if not using_assistant and chat.model is None:
        chat.model = settings.model or GIGACHAT_MODEL
    if chat.flags is None:
        chat.flags = settings.flags
    return chat


def _parse_completion(
    completion: ChatCompletion,
    response_format: Type[ModelT],
) -> ModelT:
    """Parse and validate message content from *completion* into *response_format*."""
    if not completion.choices:
        raise ValueError("Response has no choices")

    choice = completion.choices[0]

    if choice.finish_reason == "length":
        raise LengthFinishReasonError(completion)

    data = json.loads(choice.message.content)
    return response_format.model_validate(data)


def _parse_primary_completion(
    completion: ChatCompletionResponse,
    response_format: Type[ModelT],
) -> ModelT:
    """Parse and validate assistant text content from *completion* into *response_format*."""
    if not completion.messages:
        raise ValueError("Response has no messages")

    found_assistant_message = False

    for message in completion.messages:
        if message.role != "assistant":
            continue

        found_assistant_message = True

        if message.finish_reason == "length":
            raise LengthFinishReasonError(completion)

        if not message.content:
            continue

        raw_content = "".join(part.text for part in message.content if part.text is not None)
        if not raw_content:
            continue

        data = json.loads(raw_content)
        return response_format.model_validate(data)

    if not found_assistant_message:
        raise ValueError("Response has no assistant messages")

    raise ValueError("Response has no assistant text content")


def _build_access_token(token: Token) -> AccessToken:
    return AccessToken(access_token=token.tok, expires_at=token.exp, x_headers=token.x_headers)


class _BaseClient:
    _access_token: Optional[AccessToken] = None

    def __init__(
        self,
        *,
        base_url: Optional[str] = None,
        auth_url: Optional[str] = None,
        credentials: Optional[str] = None,
        scope: Optional[str] = None,
        access_token: Optional[str] = None,
        model: Optional[str] = None,
        profanity_check: Optional[bool] = None,
        user: Optional[str] = None,
        password: Optional[str] = None,
        timeout: Optional[float] = None,
        verify_ssl_certs: Optional[bool] = None,
        ca_bundle_file: Optional[str] = None,
        cert_file: Optional[str] = None,
        key_file: Optional[str] = None,
        key_file_password: Optional[str] = None,
        ssl_context: Optional[ssl.SSLContext] = None,
        flags: Optional[List[str]] = None,
        max_connections: Optional[int] = None,
        max_retries: Optional[int] = None,
        retry_backoff_factor: Optional[float] = None,
        retry_on_status_codes: Optional[Tuple[int, ...]] = None,
        **_unknown_kwargs: Any,
    ) -> None:
        if _unknown_kwargs:
            logger.warning("GigaChat: unknown kwargs - %s", _unknown_kwargs)

        kwargs: Dict[str, Any] = {
            "base_url": base_url,
            "auth_url": auth_url,
            "credentials": credentials,
            "scope": scope,
            "access_token": access_token,
            "model": model,
            "profanity_check": profanity_check,
            "user": user,
            "password": password,
            "timeout": timeout,
            "verify_ssl_certs": verify_ssl_certs,
            "ca_bundle_file": ca_bundle_file,
            "cert_file": cert_file,
            "key_file": key_file,
            "key_file_password": key_file_password,
            "ssl_context": ssl_context,
            "flags": flags,
            "max_connections": max_connections,
            "max_retries": max_retries,
            "retry_backoff_factor": retry_backoff_factor,
            "retry_on_status_codes": retry_on_status_codes,
        }
        config = {k: v for k, v in kwargs.items() if v is not None}
        self._settings = Settings(**config)
        if self._settings.access_token:
            self._access_token = AccessToken(access_token=self._settings.access_token, expires_at=0)

    @property
    def token(self) -> Optional[str]:
        if self._access_token:
            return self._access_token.access_token
        else:
            return None

    @property
    def _use_auth(self) -> bool:
        return bool(self._settings.credentials or (self._settings.user and self._settings.password))

    def _is_token_usable(self) -> bool:
        """Check if cached token is usable (exists and not expiring within buffer)."""
        if self._access_token and (
            self._access_token.expires_at == 0
            or self._access_token.expires_at > (time.time() * 1000) + self._settings.token_expiry_buffer_ms
        ):
            return True
        return False

    def _reset_token(self) -> None:
        """Reset the token."""
        self._access_token = None


class GigaChatSyncClient(_BaseClient):
    """
    Synchronous GigaChat client.

    Args:
        base_url: Address against which requests are executed.
        auth_url: Address for requesting OAuth 2.0 access token.
        credentials: Authorization data.
        scope: API version to which access is provided.
        access_token: JWE token.
        model: Name of the model to receive a response from.
        profanity_check: Censorship parameter.
        user: User name for authorization.
        password: Password for authorization.
        timeout: Timeout for requests.
        verify_ssl_certs: Check SSL certificates.
        ca_bundle_file: Path to CA bundle file.
        cert_file: Path to certificate file.
        key_file: Path to key file.
        key_file_password: Password for key file.
        ssl_context: SSL context.
        flags: Flags for GigaChat API.
        max_connections: Maximum number of simultaneous connections to the GigaChat API.
        max_retries: Maximum number of retries for transient errors.
        retry_backoff_factor: Backoff factor for retry delays.
        retry_on_status_codes: HTTP status codes that trigger a retry.
        **kwargs: Additional keyword arguments passed to parent classes.
    """

    def __init__(
        self,
        *,
        base_url: Optional[str] = None,
        auth_url: Optional[str] = None,
        credentials: Optional[str] = None,
        scope: Optional[str] = None,
        access_token: Optional[str] = None,
        model: Optional[str] = None,
        profanity_check: Optional[bool] = None,
        user: Optional[str] = None,
        password: Optional[str] = None,
        timeout: Optional[float] = None,
        verify_ssl_certs: Optional[bool] = None,
        ca_bundle_file: Optional[str] = None,
        cert_file: Optional[str] = None,
        key_file: Optional[str] = None,
        key_file_password: Optional[str] = None,
        ssl_context: Optional[ssl.SSLContext] = None,
        flags: Optional[List[str]] = None,
        max_connections: Optional[int] = None,
        max_retries: Optional[int] = None,
        retry_backoff_factor: Optional[float] = None,
        retry_on_status_codes: Optional[Tuple[int, ...]] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            base_url=base_url,
            auth_url=auth_url,
            credentials=credentials,
            scope=scope,
            access_token=access_token,
            model=model,
            profanity_check=profanity_check,
            user=user,
            password=password,
            timeout=timeout,
            verify_ssl_certs=verify_ssl_certs,
            ca_bundle_file=ca_bundle_file,
            cert_file=cert_file,
            key_file=key_file,
            key_file_password=key_file_password,
            ssl_context=ssl_context,
            flags=flags,
            max_connections=max_connections,
            max_retries=max_retries,
            retry_backoff_factor=retry_backoff_factor,
            retry_on_status_codes=retry_on_status_codes,
            **kwargs,
        )
        self._sync_token_lock = threading.RLock()
        self._client_instance: Optional[httpx.Client] = None
        self._auth_client_instance: Optional[httpx.Client] = None

    @cached_property
    def chat(self) -> ChatNamespace:
        """Return the chat namespace with primary chat methods."""
        return ChatNamespace(self)

    @cached_property
    def assistants(self) -> AssistantsSyncClient:
        """Return the assistants resource."""
        return AssistantsSyncClient(self)

    @cached_property
    def models(self) -> ModelsSyncResource:
        """Return the models resource."""
        return ModelsSyncResource(self)

    @cached_property
    def embeddings(self) -> EmbeddingsSyncResource:
        """Return the embeddings resource."""
        return EmbeddingsSyncResource(self)

    @cached_property
    def batches(self) -> BatchesSyncResource:
        """Return the batches resource."""
        return BatchesSyncResource(self)

    @cached_property
    def files(self) -> FilesSyncResource:
        """Return the files resource."""
        return FilesSyncResource(self)

    @cached_property
    def tokens(self) -> TokensSyncResource:
        """Return the tokens resource."""
        return TokensSyncResource(self)

    @cached_property
    def balance(self) -> BalanceSyncResource:
        """Return the balance resource."""
        return BalanceSyncResource(self)

    @cached_property
    def functions(self) -> FunctionsSyncResource:
        """Return the functions resource."""
        return FunctionsSyncResource(self)

    @cached_property
    def ai_check(self) -> AICheckSyncResource:
        """Return the AI check resource."""
        return AICheckSyncResource(self)

    @cached_property
    def threads(self) -> ThreadsSyncClient:
        """Return the threads resource."""
        return ThreadsSyncClient(self)

    @property
    def _client(self) -> httpx.Client:
        if self._client_instance is None:
            with self._sync_token_lock:
                if self._client_instance is None:
                    self._client_instance = httpx.Client(**_get_kwargs(self._settings))
        return self._client_instance

    @property
    def _auth_client(self) -> httpx.Client:
        if self._auth_client_instance is None:
            with self._sync_token_lock:
                if self._auth_client_instance is None:
                    self._auth_client_instance = httpx.Client(**_get_auth_kwargs(self._settings))
        return self._auth_client_instance

    def close(self) -> None:
        if self._client_instance:
            self._client_instance.close()
        if self._auth_client_instance:
            self._auth_client_instance.close()

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    def _update_token(self) -> None:
        if authorization_cvar.get() is not None:
            return

        with self._sync_token_lock:
            if self._is_token_usable():
                return

            if self._settings.credentials:
                self._access_token = auth.auth_sync(
                    self._auth_client,
                    url=self._settings.auth_url,
                    credentials=self._settings.credentials,
                    scope=self._settings.scope,
                )
                logger.debug("Token refreshed via OAuth")
            elif self._settings.user and self._settings.password:
                self._access_token = _build_access_token(
                    auth.token_sync(
                        self._client,
                        user=self._settings.user,
                        password=self._settings.password,
                    )
                )
                logger.debug("Token refreshed via password auth")

    def get_token(self) -> Optional[AccessToken]:
        """
        Return a valid access token, refreshing if necessary.

        Returns:
            Optional[AccessToken]: The access token if authentication is configured and successful.
                Returns None if:
                1. Authentication is managed via context variable (`authorization_cvar`).
                2. No authentication credentials are provided.
        """
        self._update_token()
        return self._access_token

    def tokens_count(self, input_: List[str], model: Optional[str] = None) -> List[TokensCount]:
        """Return token counts via deprecated root shim."""
        warn_deprecated_resource_api("client.tokens_count(...)", "client.tokens.count(...)")
        return self.tokens.count(input_, model=model)

    def get_models(self) -> Models:
        """Return a list of available models via deprecated root shim."""
        warn_deprecated_resource_api("client.get_models()", "client.models.list()")
        return self.models.list()

    def get_model(self, model: str) -> Model:
        """Return a model description via deprecated root shim."""
        warn_deprecated_resource_api("client.get_model(...)", "client.models.retrieve(...)")
        return self.models.retrieve(model)

    def get_file_content(self, file_id: str) -> File:
        """Return file content via deprecated root shim."""
        warn_deprecated_resource_api("client.get_file_content(...)", "client.files.retrieve_content(...)")
        return self.files.retrieve_content(file_id)

    def get_image(self, file_id: str) -> File:
        """Return file content via deprecated root shim."""
        warn_deprecated_resource_api("client.get_image(...)", "client.files.retrieve_content(...)")
        return self.files.retrieve_content(file_id)

    def upload_file(
        self,
        file: FileTypes,
        purpose: Literal["general", "assistant"] = "general",
    ) -> UploadedFile:
        """Upload a file via deprecated root shim."""
        warn_deprecated_resource_api("client.upload_file(...)", "client.files.upload(...)")
        return self.files.upload(file, purpose=purpose)

    def get_file(self, file: str) -> UploadedFile:
        """Return information about a file via deprecated root shim."""
        warn_deprecated_resource_api("client.get_file(...)", "client.files.retrieve(...)")
        return self.files.retrieve(file)

    def get_files(self) -> UploadedFiles:
        """Return a list of uploaded files via deprecated root shim."""
        warn_deprecated_resource_api("client.get_files()", "client.files.list()")
        return self.files.list()

    def delete_file(
        self,
        file: str,
    ) -> DeletedFile:
        """Delete a file via deprecated root shim."""
        warn_deprecated_resource_api("client.delete_file(...)", "client.files.delete(...)")
        return self.files.delete(file)

    def create_batch(self, file: FileContent, method: Literal["chat_completions", "embedder"]) -> Batch:
        """Create a batch task via deprecated root shim."""
        warn_deprecated_resource_api("client.create_batch(...)", "client.batches.create(...)")
        return self.batches.create(file, method)

    def get_batches(self, batch_id: Optional[str] = None) -> Batches:
        """Return batch tasks via deprecated root shim."""
        if batch_id is None:
            warn_deprecated_resource_api("client.get_batches()", "client.batches.list()")
            return self.batches.list()

        warn_deprecated_resource_api("client.get_batches(...)", "client.batches.retrieve(...)")
        return self.batches.retrieve(batch_id)

    @_with_retry
    @_with_auth
    def _chat_create(self, payload: Union[ChatCompletionRequest, Dict[str, Any], str]) -> ChatCompletionResponse:
        """Return a primary chat completion based on the provided messages."""
        chat_data = _parse_chat_completion(payload, self._settings)
        return chat_completions.chat_sync(self._client, chat=chat_data, access_token=self.token)

    @_with_retry_stream
    @_with_auth_stream
    def _chat_stream(
        self, payload: Union[ChatCompletionRequest, Dict[str, Any], str]
    ) -> Iterator[PrimaryChatCompletionChunk]:
        """Return a primary streaming chat completion based on the provided messages."""
        chat_data = _parse_chat_completion(payload, self._settings)
        yield from chat_completions.stream_sync(self._client, chat=chat_data, access_token=self.token)

    def _chat_parse(
        self,
        payload: Union[ChatCompletionRequest, Dict[str, Any], str],
        *,
        response_format: Type[ModelT],
        strict: bool = True,
    ) -> Tuple[ChatCompletionResponse, ModelT]:
        """Send a primary chat request and parse the response into a structured object."""
        chat_data = _prepare_chat_completion_for_parse(payload, self._settings, response_format, strict)
        completion = self._chat_create(chat_data)
        parsed = _parse_primary_completion(completion, response_format)
        return completion, parsed

    @_with_retry
    @_with_auth
    def _chat(self, payload: Union[Chat, Dict[str, Any], str]) -> ChatCompletion:
        """Return a root chat completion based on the provided messages."""
        _validate_response_format(payload)
        chat_data = _parse_chat(payload, self._settings)
        return chat.chat_sync(self._client, chat=chat_data, access_token=self.token)

    @_with_retry_stream
    @_with_auth_stream
    def _stream(self, payload: Union[Chat, Dict[str, Any], str]) -> Iterator[ChatCompletionChunk]:
        """Return a root streaming chat completion based on the provided messages."""
        chat_data = _parse_chat(payload, self._settings)

        yield from chat.stream_sync(self._client, chat=chat_data, access_token=self.token)

    def _chat_parse_root(
        self,
        payload: Union[Chat, Dict[str, Any], str],
        *,
        response_format: Type[ModelT],
        strict: bool = True,
    ) -> Tuple[ChatCompletion, ModelT]:
        """Send a root chat request and parse the response into a structured object."""
        chat_data = _prepare_chat_for_parse(payload, self._settings, response_format, strict)
        completion = self._chat(chat_data)
        parsed = _parse_completion(completion, response_format)
        return completion, parsed

    def chat_parse(
        self,
        payload: Union[Chat, Dict[str, Any], str],
        *,
        response_format: Type[ModelT],
        strict: bool = True,
    ) -> Tuple[ChatCompletion, ModelT]:
        """Parse via the root chat compatibility shim.

        .. note:: **Beta.** This feature may not work correctly with all model versions.

        *response_format* accepts a Pydantic ``BaseModel`` subclass.
        The method derives a JSON Schema from it, sends the request via the root
        chat contract, then parses and validates ``message.content``.

        Raise :class:`~gigachat.exceptions.LengthFinishReasonError` if
        ``finish_reason`` is ``"length"`` (truncated response).
        """
        return self._chat_parse_root(payload, response_format=response_format, strict=strict)

    def get_balance(self) -> Balance:
        """Return balance via deprecated root shim."""
        warn_deprecated_resource_api("client.get_balance()", "client.balance.get()")
        return self.balance.get()

    def openapi_function_convert(self, openapi_function: str) -> OpenApiFunctions:
        """Convert an OpenAPI function description via deprecated root shim."""
        warn_deprecated_resource_api("client.openapi_function_convert(...)", "client.functions.convert_openapi(...)")
        return self.functions.convert_openapi(openapi_function)

    def validate_function(self, function: Union[Function, Dict[str, Any]]) -> FunctionValidationResult:
        """Validate a function definition via deprecated root shim."""
        warn_deprecated_resource_api("client.validate_function(...)", "client.functions.validate(...)")
        return self.functions.validate(function)

    def check_ai(self, text: str, model: str) -> AICheckResult:
        """Check text via deprecated root shim."""
        warn_deprecated_resource_api("client.check_ai(...)", "client.ai_check.check(...)")
        return self.ai_check.check(text, model)

    def stream(self, payload: Union[Chat, Dict[str, Any], str]) -> Iterator[ChatCompletionChunk]:
        """Stream via the root chat compatibility shim."""
        yield from self._stream(payload)


class GigaChatAsyncClient(_BaseClient):
    """
    Asynchronous GigaChat client.

    Args:
        base_url: Address against which requests are executed.
        auth_url: Address for requesting OAuth 2.0 access token.
        credentials: Authorization data.
        scope: API version to which access is provided.
        access_token: JWE token.
        model: Name of the model to receive a response from.
        profanity_check: Censorship parameter.
        user: User name for authorization.
        password: Password for authorization.
        timeout: Timeout for requests.
        verify_ssl_certs: Check SSL certificates.
        ca_bundle_file: Path to CA bundle file.
        cert_file: Path to certificate file.
        key_file: Path to key file.
        key_file_password: Password for key file.
        ssl_context: SSL context.
        flags: Flags for GigaChat API.
        max_connections: Maximum number of simultaneous connections to the GigaChat API.
        max_retries: Maximum number of retries for transient errors.
        retry_backoff_factor: Backoff factor for retry delays.
        retry_on_status_codes: HTTP status codes that trigger a retry.
        **kwargs: Additional keyword arguments passed to parent classes.
    """

    def __init__(
        self,
        *,
        base_url: Optional[str] = None,
        auth_url: Optional[str] = None,
        credentials: Optional[str] = None,
        scope: Optional[str] = None,
        access_token: Optional[str] = None,
        model: Optional[str] = None,
        profanity_check: Optional[bool] = None,
        user: Optional[str] = None,
        password: Optional[str] = None,
        timeout: Optional[float] = None,
        verify_ssl_certs: Optional[bool] = None,
        ca_bundle_file: Optional[str] = None,
        cert_file: Optional[str] = None,
        key_file: Optional[str] = None,
        key_file_password: Optional[str] = None,
        ssl_context: Optional[ssl.SSLContext] = None,
        flags: Optional[List[str]] = None,
        max_connections: Optional[int] = None,
        max_retries: Optional[int] = None,
        retry_backoff_factor: Optional[float] = None,
        retry_on_status_codes: Optional[Tuple[int, ...]] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            base_url=base_url,
            auth_url=auth_url,
            credentials=credentials,
            scope=scope,
            access_token=access_token,
            model=model,
            profanity_check=profanity_check,
            user=user,
            password=password,
            timeout=timeout,
            verify_ssl_certs=verify_ssl_certs,
            ca_bundle_file=ca_bundle_file,
            cert_file=cert_file,
            key_file=key_file,
            key_file_password=key_file_password,
            ssl_context=ssl_context,
            flags=flags,
            max_connections=max_connections,
            max_retries=max_retries,
            retry_backoff_factor=retry_backoff_factor,
            retry_on_status_codes=retry_on_status_codes,
            **kwargs,
        )
        self._async_token_lock = asyncio.Lock()
        self._aclient_instance: Optional[httpx.AsyncClient] = None
        self._auth_aclient_instance: Optional[httpx.AsyncClient] = None

    @cached_property
    def achat(self) -> AsyncChatNamespace:
        """Return the async chat namespace with primary chat methods."""
        return AsyncChatNamespace(self)

    @cached_property
    def a_assistants(self) -> AssistantsAsyncClient:
        """Return the async assistants resource."""
        return AssistantsAsyncClient(self)

    @cached_property
    def a_models(self) -> ModelsAsyncResource:
        """Return the async models resource."""
        return ModelsAsyncResource(self)

    @cached_property
    def a_embeddings(self) -> EmbeddingsAsyncResource:
        """Return the async embeddings resource."""
        return EmbeddingsAsyncResource(self)

    @cached_property
    def a_batches(self) -> BatchesAsyncResource:
        """Return the async batches resource."""
        return BatchesAsyncResource(self)

    @cached_property
    def a_files(self) -> FilesAsyncResource:
        """Return the async files resource."""
        return FilesAsyncResource(self)

    @cached_property
    def a_tokens(self) -> TokensAsyncResource:
        """Return the async tokens resource."""
        return TokensAsyncResource(self)

    @cached_property
    def a_balance(self) -> BalanceAsyncResource:
        """Return the async balance resource."""
        return BalanceAsyncResource(self)

    @cached_property
    def a_functions(self) -> FunctionsAsyncResource:
        """Return the async functions resource."""
        return FunctionsAsyncResource(self)

    @cached_property
    def a_ai_check(self) -> AICheckAsyncResource:
        """Return the async AI check resource."""
        return AICheckAsyncResource(self)

    @cached_property
    def a_threads(self) -> ThreadsAsyncClient:
        """Return the async threads resource."""
        return ThreadsAsyncClient(self)

    @property
    def _aclient(self) -> httpx.AsyncClient:
        if self._aclient_instance is None:
            self._aclient_instance = httpx.AsyncClient(**_get_kwargs(self._settings))
        return self._aclient_instance

    @property
    def _auth_aclient(self) -> httpx.AsyncClient:
        if self._auth_aclient_instance is None:
            self._auth_aclient_instance = httpx.AsyncClient(**_get_auth_kwargs(self._settings))
        return self._auth_aclient_instance

    async def aclose(self) -> None:
        if self._aclient_instance:
            await self._aclient_instance.aclose()
        if self._auth_aclient_instance:
            await self._auth_aclient_instance.aclose()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.aclose()

    async def _aupdate_token(self) -> None:
        if authorization_cvar.get() is not None:
            return
        async with self._async_token_lock:
            if self._is_token_usable():
                return
            if self._settings.credentials:
                self._access_token = await auth.auth_async(
                    self._auth_aclient,
                    url=self._settings.auth_url,
                    credentials=self._settings.credentials,
                    scope=self._settings.scope,
                )
                logger.debug("Token refreshed via OAuth")
            elif self._settings.user and self._settings.password:
                self._access_token = _build_access_token(
                    await auth.token_async(
                        self._aclient,
                        user=self._settings.user,
                        password=self._settings.password,
                    )
                )
                logger.debug("Token refreshed via password auth")

    async def aget_token(self) -> Optional[AccessToken]:
        """
        Return a valid access token, refreshing if necessary.

        Returns:
            Optional[AccessToken]: The access token if authentication is configured and successful.
                Returns None if:
                1. Authentication is managed via context variable (`authorization_cvar`).
                2. No authentication credentials are provided.
        """
        await self._aupdate_token()
        return self._access_token

    async def atokens_count(self, input_: List[str], model: Optional[str] = None) -> List[TokensCount]:
        """Return token counts via deprecated root shim."""
        warn_deprecated_resource_api("client.atokens_count(...)", "client.a_tokens.count(...)")
        return await self.a_tokens.count(input_, model=model)

    async def aembeddings(self, texts: List[str], model: str = "Embeddings") -> Embeddings:
        """Return embeddings via deprecated root shim."""
        warn_deprecated_resource_api("client.aembeddings(...)", "client.a_embeddings.create(...)")
        return await self.a_embeddings.create(texts, model=model)

    async def aget_models(self) -> Models:
        """Return a list of available models via deprecated root shim."""
        warn_deprecated_resource_api("client.aget_models()", "client.a_models.list()")
        return await self.a_models.list()

    async def aget_file_content(self, file_id: str) -> File:
        """Return file content via deprecated root shim."""
        warn_deprecated_resource_api("client.aget_file_content(...)", "client.a_files.retrieve_content(...)")
        return await self.a_files.retrieve_content(file_id)

    async def aget_image(self, file_id: str) -> File:
        """Return file content via deprecated root shim."""
        warn_deprecated_resource_api("client.aget_image(...)", "client.a_files.retrieve_content(...)")
        return await self.a_files.retrieve_content(file_id)

    async def aget_model(self, model: str) -> Model:
        """Return a model description via deprecated root shim."""
        warn_deprecated_resource_api("client.aget_model(...)", "client.a_models.retrieve(...)")
        return await self.a_models.retrieve(model)

    @_awith_retry
    @_awith_auth
    async def _achat(self, payload: Union[Chat, Dict[str, Any], str]) -> ChatCompletion:
        """Return a root chat completion based on the provided messages."""
        _validate_response_format(payload)
        chat_data = _parse_chat(payload, self._settings)

        return await chat.chat_async(self._aclient, chat=chat_data, access_token=self.token)

    @_awith_retry
    @_awith_auth
    async def _achat_create(self, payload: Union[ChatCompletionRequest, Dict[str, Any], str]) -> ChatCompletionResponse:
        """Return a primary chat completion based on the provided messages."""
        chat_data = _parse_chat_completion(payload, self._settings)
        return await chat_completions.chat_async(self._aclient, chat=chat_data, access_token=self.token)

    @_awith_retry_stream
    @_awith_auth_stream
    def _achat_stream(
        self, payload: Union[ChatCompletionRequest, Dict[str, Any], str]
    ) -> AsyncIterator[PrimaryChatCompletionChunk]:
        """Return a primary streaming chat completion based on the provided messages."""
        chat_data = _parse_chat_completion(payload, self._settings)
        return chat_completions.stream_async(self._aclient, chat=chat_data, access_token=self.token)

    @_awith_retry_stream
    @_awith_auth_stream
    def _astream(self, payload: Union[Chat, Dict[str, Any], str]) -> AsyncIterator[ChatCompletionChunk]:
        """Return a root streaming chat completion based on the provided messages."""
        chat_data = _parse_chat(payload, self._settings)
        return chat.stream_async(self._aclient, chat=chat_data, access_token=self.token)

    async def _achat_parse(
        self,
        payload: Union[ChatCompletionRequest, Dict[str, Any], str],
        *,
        response_format: Type[ModelT],
        strict: bool = True,
    ) -> Tuple[ChatCompletionResponse, ModelT]:
        """Send a primary chat request and parse the response into a structured object."""
        chat_data = _prepare_chat_completion_for_parse(payload, self._settings, response_format, strict)
        completion = await self._achat_create(chat_data)
        parsed = _parse_primary_completion(completion, response_format)
        return completion, parsed

    async def _achat_parse_root(
        self,
        payload: Union[Chat, Dict[str, Any], str],
        *,
        response_format: Type[ModelT],
        strict: bool = True,
    ) -> Tuple[ChatCompletion, ModelT]:
        """Send a root chat request and parse the response into *response_format*."""
        chat_data = _prepare_chat_for_parse(payload, self._settings, response_format, strict)
        completion = await self._achat(chat_data)
        parsed = _parse_completion(completion, response_format)
        return completion, parsed

    async def achat_parse(
        self,
        payload: Union[Chat, Dict[str, Any], str],
        *,
        response_format: Type[ModelT],
        strict: bool = True,
    ) -> Tuple[ChatCompletion, ModelT]:
        """Parse via the root async chat compatibility shim.

        .. note:: **Beta.** This feature may not work correctly with all model versions.

        Async version of :meth:`GigaChatSyncClient.chat_parse`.

        Raise :class:`~gigachat.exceptions.LengthFinishReasonError` if
        ``finish_reason`` is ``"length"`` (truncated response).
        """
        return await self._achat_parse_root(payload, response_format=response_format, strict=strict)

    async def aupload_file(
        self,
        file: FileTypes,
        purpose: Literal["general", "assistant"] = "general",
    ) -> UploadedFile:
        """Upload a file via deprecated root shim."""
        warn_deprecated_resource_api("client.aupload_file(...)", "client.a_files.upload(...)")
        return await self.a_files.upload(file, purpose=purpose)

    async def aget_file(self, file: str) -> UploadedFile:
        """Return information about a file via deprecated root shim."""
        warn_deprecated_resource_api("client.aget_file(...)", "client.a_files.retrieve(...)")
        return await self.a_files.retrieve(file)

    async def aget_files(self) -> UploadedFiles:
        """Return a list of uploaded files via deprecated root shim."""
        warn_deprecated_resource_api("client.aget_files()", "client.a_files.list()")
        return await self.a_files.list()

    async def adelete_file(
        self,
        file: str,
    ) -> DeletedFile:
        """Delete a file via deprecated root shim."""
        warn_deprecated_resource_api("client.adelete_file(...)", "client.a_files.delete(...)")
        return await self.a_files.delete(file)

    async def acreate_batch(self, file: FileContent, method: Literal["chat_completions", "embedder"]) -> Batch:
        """Create a batch task via deprecated root shim."""
        warn_deprecated_resource_api("client.acreate_batch(...)", "client.a_batches.create(...)")
        return await self.a_batches.create(file, method)

    async def aget_batches(self, batch_id: Optional[str] = None) -> Batches:
        """Return batch tasks via deprecated root shim."""
        if batch_id is None:
            warn_deprecated_resource_api("client.aget_batches()", "client.a_batches.list()")
            return await self.a_batches.list()

        warn_deprecated_resource_api("client.aget_batches(...)", "client.a_batches.retrieve(...)")
        return await self.a_batches.retrieve(batch_id)

    async def aget_balance(self) -> Balance:
        """Return balance via deprecated root shim."""
        warn_deprecated_resource_api("client.aget_balance()", "client.a_balance.get()")
        return await self.a_balance.get()

    async def aopenapi_function_convert(self, openapi_function: str) -> OpenApiFunctions:
        """Convert an OpenAPI function description via deprecated root shim."""
        warn_deprecated_resource_api("client.aopenapi_function_convert(...)", "client.a_functions.convert_openapi(...)")
        return await self.a_functions.convert_openapi(openapi_function)

    async def avalidate_function(self, function: Union[Function, Dict[str, Any]]) -> FunctionValidationResult:
        """Validate a function definition via deprecated root shim."""
        warn_deprecated_resource_api("client.avalidate_function(...)", "client.a_functions.validate(...)")
        return await self.a_functions.validate(function)

    async def acheck_ai(self, text: str, model: str) -> AICheckResult:
        """Check text via deprecated root shim."""
        warn_deprecated_resource_api("client.acheck_ai(...)", "client.a_ai_check.check(...)")
        return await self.a_ai_check.check(text, model)

    def astream(self, payload: Union[Chat, Dict[str, Any], str]) -> AsyncIterator[ChatCompletionChunk]:
        """Stream via the root async chat compatibility shim."""
        return self._astream(payload)


class GigaChat(GigaChatSyncClient, GigaChatAsyncClient):
    """
    GigaChat client.

    Args:
        base_url: Address against which requests are executed.
        auth_url: Address for requesting OAuth 2.0 access token.
        credentials: Authorization data.
        scope: API version to which access is provided.
        access_token: JWE token.
        model: Name of the model to receive a response from.
        profanity_check: Censorship parameter.
        user: User name for authorization.
        password: Password for authorization.
        timeout: Timeout for requests.
        verify_ssl_certs: Check SSL certificates.
        ca_bundle_file: Path to CA bundle file.
        cert_file: Path to certificate file.
        key_file: Path to key file.
        key_file_password: Password for key file.
        ssl_context: SSL context.
        flags: Flags for GigaChat API.
        max_connections: Maximum number of simultaneous connections to the GigaChat API.
        max_retries: Maximum number of retries for transient errors.
        retry_backoff_factor: Backoff factor for retry delays.
        retry_on_status_codes: HTTP status codes that trigger a retry.
        **kwargs: Additional keyword arguments passed to parent classes.
    """

    def __init__(
        self,
        *,
        base_url: Optional[str] = None,
        auth_url: Optional[str] = None,
        credentials: Optional[str] = None,
        scope: Optional[str] = None,
        access_token: Optional[str] = None,
        model: Optional[str] = None,
        profanity_check: Optional[bool] = None,
        user: Optional[str] = None,
        password: Optional[str] = None,
        timeout: Optional[float] = None,
        verify_ssl_certs: Optional[bool] = None,
        ca_bundle_file: Optional[str] = None,
        cert_file: Optional[str] = None,
        key_file: Optional[str] = None,
        key_file_password: Optional[str] = None,
        ssl_context: Optional[ssl.SSLContext] = None,
        flags: Optional[List[str]] = None,
        max_connections: Optional[int] = None,
        max_retries: Optional[int] = None,
        retry_backoff_factor: Optional[float] = None,
        retry_on_status_codes: Optional[Tuple[int, ...]] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            base_url=base_url,
            auth_url=auth_url,
            credentials=credentials,
            scope=scope,
            access_token=access_token,
            model=model,
            profanity_check=profanity_check,
            user=user,
            password=password,
            timeout=timeout,
            verify_ssl_certs=verify_ssl_certs,
            ca_bundle_file=ca_bundle_file,
            cert_file=cert_file,
            key_file=key_file,
            key_file_password=key_file_password,
            ssl_context=ssl_context,
            flags=flags,
            max_connections=max_connections,
            max_retries=max_retries,
            retry_backoff_factor=retry_backoff_factor,
            retry_on_status_codes=retry_on_status_codes,
            **kwargs,
        )

    async def aclose(self) -> None:
        self.close()
        await super().aclose()

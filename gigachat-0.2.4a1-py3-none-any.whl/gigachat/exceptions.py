from typing import TYPE_CHECKING, Optional, Union

import httpx

if TYPE_CHECKING:
    from gigachat.models.chat import ChatCompletion
    from gigachat.models.chat_completions import ChatCompletionResponse

__all__ = [
    "GigaChatException",
    "ResponseError",
    "BadRequestError",
    "AuthenticationError",
    "ForbiddenError",
    "NotFoundError",
    "RequestEntityTooLargeError",
    "UnprocessableEntityError",
    "RateLimitError",
    "ServerError",
    "LengthFinishReasonError",
    "ModelNotSpecifiedError",
]


class GigaChatException(Exception):
    """Base exception for GigaChat library."""


class ResponseError(GigaChatException):
    """Exception raised when API response contains an error."""

    def __init__(
        self,
        url: Union[httpx.URL, str],
        status_code: int,
        content: Optional[bytes],
        headers: Optional[httpx.Headers],
    ) -> None:
        self.url = url
        self.status_code = status_code
        self.content = content
        self.headers = headers
        super().__init__(f"{status_code} {url}")

    def __str__(self) -> str:
        content = self.content.decode("utf-8", errors="replace") if self.content is not None else None
        return f"{self.status_code} {self.url}: {content!r}, {self.headers!r}"


class BadRequestError(ResponseError):
    """Exception raised for 400 Bad Request."""


class AuthenticationError(ResponseError):
    """Exception raised when authentication fails (401 Unauthorized)."""


class ForbiddenError(ResponseError):
    """Exception raised for 403 Forbidden."""


class NotFoundError(ResponseError):
    """Exception raised for 404 Not Found."""


class RequestEntityTooLargeError(ResponseError):
    """Exception raised for 413 Request Entity Too Large."""


class UnprocessableEntityError(ResponseError):
    """Exception raised for 422 Unprocessable Entity."""


class RateLimitError(ResponseError):
    """Exception raised for 429 Too Many Requests."""

    @property
    def retry_after(self) -> float:
        """Return the number of seconds to wait before retrying."""
        if self.headers:
            retry_after = self.headers.get("retry-after")
            if retry_after:
                try:
                    return float(retry_after)
                except ValueError:
                    pass
        return 0.0


class ServerError(ResponseError):
    """Exception raised for 5xx Server Errors."""


class LengthFinishReasonError(GigaChatException):
    """Exception raised when finish_reason is 'length' (response truncated)."""

    def __init__(self, completion: Union["ChatCompletion", "ChatCompletionResponse"]) -> None:
        self.completion = completion
        super().__init__("Could not parse response content as the length limit was reached")


class ModelNotSpecifiedError(GigaChatException):
    """Exception raised when no model is specified for a request."""

    def __init__(self) -> None:
        super().__init__(
            "No model specified. Pass `model` in the request payload, "
            "set `GigaChat(model=...)` or the GIGACHAT_MODEL environment variable. "
            "Use `get_models()` to list available models."
        )
